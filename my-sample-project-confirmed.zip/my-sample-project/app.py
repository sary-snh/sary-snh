# Simple Python script
import sqlite3

# Connect to database
connection = sqlite3.connect("sample.db")
cursor = connection.cursor()

# Create table
cursor.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)")

# Insert sample data
cursor.execute("INSERT INTO users (name) VALUES ('Alice')")
cursor.execute("INSERT INTO users (name) VALUES ('Bob')")

connection.commit()

# Fetch data
cursor.execute("SELECT * FROM users")
print("Users:", cursor.fetchall())

connection.close()
