-- SQL script to create a sample table
CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    name TEXT,
    price REAL
);

INSERT INTO products (name, price) VALUES ('Laptop', 1200);
INSERT INTO products (name, price) VALUES ('Phone', 800);
